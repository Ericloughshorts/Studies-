export interface User {
  id: string;
  full_name: string;
  phone_number: string;
  email: string;
  password: string;
  is_admin: boolean;
  balance: number;
  created_at: string;
}

export interface Investment {
  id: string;
  user_id: string;
  tool_id: string;
  amount: number;
  roi_percentage: number;
  start_date: string;
  end_date: string;
  status: 'active' | 'completed';
  final_amount: number;
}

export interface Tool {
  id: string;
  name: string;
  description: string;
  image_url: string;
  price: number;
  category: string;
  available: boolean;
}

export interface DepositRequest {
  id: string;
  user_id: string;
  amount: number;
  phone_number: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

export interface WithdrawRequest {
  id: string;
  user_id: string;
  amount: number;
  phone_number: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}