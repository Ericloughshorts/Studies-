import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { User, DepositRequest, WithdrawRequest, Tool, Investment } from '../../types';
import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  Package, 
  CheckCircle, 
  XCircle,
  Eye,
  Trash2,
  Edit,
  Plus
} from 'lucide-react';

export function AdminDashboard() {
  const { logout } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>([]);
  const [withdrawRequests, setWithdrawRequests] = useState<WithdrawRequest[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [showToolForm, setShowToolForm] = useState(false);
  const [toolForm, setToolForm] = useState({
    name: '',
    description: '',
    image_url: '',
    price: '',
    category: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setUsers(JSON.parse(localStorage.getItem('users') || '[]'));
    setDepositRequests(JSON.parse(localStorage.getItem('depositRequests') || '[]'));
    setWithdrawRequests(JSON.parse(localStorage.getItem('withdrawRequests') || '[]'));
    setTools(JSON.parse(localStorage.getItem('tools') || '[]'));
    setInvestments(JSON.parse(localStorage.getItem('investments') || '[]'));
  };

  const handleDepositApproval = (requestId: string, approved: boolean) => {
    const requests = [...depositRequests];
    const requestIndex = requests.findIndex(r => r.id === requestId);
    
    if (requestIndex !== -1) {
      requests[requestIndex].status = approved ? 'approved' : 'rejected';
      
      if (approved) {
        // Update user balance
        const usersList = [...users];
        const userIndex = usersList.findIndex(u => u.id === requests[requestIndex].user_id);
        if (userIndex !== -1) {
          usersList[userIndex].balance += requests[requestIndex].amount;
          setUsers(usersList);
          localStorage.setItem('users', JSON.stringify(usersList));
        }
      }
      
      setDepositRequests(requests);
      localStorage.setItem('depositRequests', JSON.stringify(requests));
    }
  };

  const handleWithdrawApproval = (requestId: string, approved: boolean) => {
    const requests = [...withdrawRequests];
    const requestIndex = requests.findIndex(r => r.id === requestId);
    
    if (requestIndex !== -1) {
      requests[requestIndex].status = approved ? 'approved' : 'rejected';
      
      if (approved) {
        // Update user balance
        const usersList = [...users];
        const userIndex = usersList.findIndex(u => u.id === requests[requestIndex].user_id);
        if (userIndex !== -1) {
          usersList[userIndex].balance -= requests[requestIndex].amount;
          setUsers(usersList);
          localStorage.setItem('users', JSON.stringify(usersList));
        }
      }
      
      setWithdrawRequests(requests);
      localStorage.setItem('withdrawRequests', JSON.stringify(requests));
    }
  };

  const handleToolSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTool: Tool = {
      id: `tool-${Date.now()}`,
      name: toolForm.name,
      description: toolForm.description,
      image_url: toolForm.image_url,
      price: parseFloat(toolForm.price),
      category: toolForm.category,
      available: true
    };

    const updatedTools = [...tools, newTool];
    setTools(updatedTools);
    localStorage.setItem('tools', JSON.stringify(updatedTools));
    
    setToolForm({ name: '', description: '', image_url: '', price: '', category: '' });
    setShowToolForm(false);
  };

  const deleteUser = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      const updatedUsers = users.filter(u => u.id !== userId);
      setUsers(updatedUsers);
      localStorage.setItem('users', JSON.stringify(updatedUsers));
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.full_name : 'Unknown User';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <Button onClick={logout} variant="secondary">
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="text-center">
            <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-gray-900">{users.length}</h3>
            <p className="text-gray-600">Total Users</p>
          </Card>
          <Card className="text-center">
            <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-gray-900">{depositRequests.filter(r => r.status === 'pending').length}</h3>
            <p className="text-gray-600">Pending Deposits</p>
          </Card>
          <Card className="text-center">
            <TrendingUp className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-gray-900">{investments.length}</h3>
            <p className="text-gray-600">Active Investments</p>
          </Card>
          <Card className="text-center">
            <Package className="w-8 h-8 text-orange-600 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-gray-900">{tools.length}</h3>
            <p className="text-gray-600">Available Tools</p>
          </Card>
        </div>

        {/* Users Table */}
        <Card className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Users Management</h2>
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Name</th>
                  <th className="text-left py-2">Email</th>
                  <th className="text-left py-2">Phone</th>
                  <th className="text-left py-2">Balance</th>
                  <th className="text-left py-2">Role</th>
                  <th className="text-left py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id} className="border-b">
                    <td className="py-2">{user.full_name}</td>
                    <td className="py-2">{user.email}</td>
                    <td className="py-2">{user.phone_number}</td>
                    <td className="py-2">RWF {user.balance.toLocaleString()}</td>
                    <td className="py-2">{user.is_admin ? 'Admin' : 'User'}</td>
                    <td className="py-2">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="secondary">
                          <Eye className="w-4 h-4" />
                        </Button>
                        {!user.is_admin && (
                          <Button size="sm" variant="danger" onClick={() => deleteUser(user.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Deposit Requests */}
        <Card className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Deposit Requests</h2>
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">User</th>
                  <th className="text-left py-2">Amount</th>
                  <th className="text-left py-2">Phone</th>
                  <th className="text-left py-2">Status</th>
                  <th className="text-left py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {depositRequests.map(request => (
                  <tr key={request.id} className="border-b">
                    <td className="py-2">{getUserName(request.user_id)}</td>
                    <td className="py-2">RWF {request.amount.toLocaleString()}</td>
                    <td className="py-2">{request.phone_number}</td>
                    <td className="py-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        request.status === 'approved' ? 'bg-green-100 text-green-800' :
                        request.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {request.status}
                      </span>
                    </td>
                    <td className="py-2">
                      {request.status === 'pending' && (
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="success"
                            onClick={() => handleDepositApproval(request.id, true)}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="danger"
                            onClick={() => handleDepositApproval(request.id, false)}
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Withdraw Requests */}
        <Card className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Withdraw Requests</h2>
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">User</th>
                  <th className="text-left py-2">Amount</th>
                  <th className="text-left py-2">Phone</th>
                  <th className="text-left py-2">Status</th>
                  <th className="text-left py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {withdrawRequests.map(request => (
                  <tr key={request.id} className="border-b">
                    <td className="py-2">{getUserName(request.user_id)}</td>
                    <td className="py-2">RWF {request.amount.toLocaleString()}</td>
                    <td className="py-2">{request.phone_number}</td>
                    <td className="py-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        request.status === 'approved' ? 'bg-green-100 text-green-800' :
                        request.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {request.status}
                      </span>
                    </td>
                    <td className="py-2">
                      {request.status === 'pending' && (
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="success"
                            onClick={() => handleWithdrawApproval(request.id, true)}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="danger"
                            onClick={() => handleWithdrawApproval(request.id, false)}
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Tools Management */}
        <Card>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Tools Management</h2>
            <Button onClick={() => setShowToolForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Tool
            </Button>
          </div>
          
          {showToolForm && (
            <div className="bg-gray-50 p-4 rounded-lg mb-4">
              <form onSubmit={handleToolSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Tool Name"
                  value={toolForm.name}
                  onChange={(e) => setToolForm(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
                <Input
                  label="Price (RWF)"
                  type="number"
                  value={toolForm.price}
                  onChange={(e) => setToolForm(prev => ({ ...prev, price: e.target.value }))}
                  required
                />
                <Input
                  label="Category"
                  value={toolForm.category}
                  onChange={(e) => setToolForm(prev => ({ ...prev, category: e.target.value }))}
                  required
                />
                <Input
                  label="Image URL"
                  value={toolForm.image_url}
                  onChange={(e) => setToolForm(prev => ({ ...prev, image_url: e.target.value }))}
                  placeholder="https://images.pexels.com/..."
                />
                <div className="md:col-span-2">
                  <Input
                    label="Description"
                    value={toolForm.description}
                    onChange={(e) => setToolForm(prev => ({ ...prev, description: e.target.value }))}
                    required
                  />
                </div>
                <div className="md:col-span-2 flex space-x-2">
                  <Button type="submit">Add Tool</Button>
                  <Button type="button" variant="secondary" onClick={() => setShowToolForm(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {tools.map(tool => (
              <div key={tool.id} className="border rounded-lg p-4">
                <img 
                  src={tool.image_url || 'https://images.pexels.com/photos/5483077/pexels-photo-5483077.jpeg'} 
                  alt={tool.name}
                  className="w-full h-32 object-cover rounded mb-2"
                />
                <h3 className="font-semibold">{tool.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{tool.description}</p>
                <p className="text-lg font-bold text-green-600">RWF {tool.price.toLocaleString()}</p>
              </div>
            ))}
          </div>
        </Card>
      </main>
    </div>
  );
}