import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Tool, Investment, DepositRequest, WithdrawRequest } from '../../types';
import { 
  Wallet, 
  TrendingUp, 
  Clock, 
  DollarSign, 
  Package,
  LogOut,
  Calendar,
  ArrowUpRight,
  ArrowDownLeft
} from 'lucide-react';

export function UserDashboard() {
  const { currentUser, logout } = useAuth();
  const [tools, setTools] = useState<Tool[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [depositForm, setDepositForm] = useState({ amount: '', phone_number: '' });
  const [withdrawForm, setWithdrawForm] = useState({ amount: '', phone_number: '' });
  const [showDepositForm, setShowDepositForm] = useState(false);
  const [showWithdrawForm, setShowWithdrawForm] = useState(false);

  useEffect(() => {
    loadData();
    // Process investments ROI
    processInvestments();
  }, []);

  const loadData = () => {
    setTools(JSON.parse(localStorage.getItem('tools') || '[]').filter((tool: Tool) => tool.available));
    setInvestments(JSON.parse(localStorage.getItem('investments') || '[]').filter((inv: Investment) => inv.user_id === currentUser?.id));
  };

  const processInvestments = () => {
    const allInvestments: Investment[] = JSON.parse(localStorage.getItem('investments') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    let hasUpdates = false;

    const updatedInvestments = allInvestments.map(investment => {
      if (investment.status === 'active' && new Date() >= new Date(investment.end_date)) {
        // Investment has matured
        const userIndex = users.findIndex((u: any) => u.id === investment.user_id);
        if (userIndex !== -1) {
          users[userIndex].balance += investment.final_amount;
          hasUpdates = true;
        }
        return { ...investment, status: 'completed' as const };
      }
      return investment;
    });

    if (hasUpdates) {
      localStorage.setItem('investments', JSON.stringify(updatedInvestments));
      localStorage.setItem('users', JSON.stringify(users));
      
      // Update current user data
      const updatedCurrentUser = users.find((u: any) => u.id === currentUser?.id);
      if (updatedCurrentUser) {
        localStorage.setItem('currentUser', JSON.stringify(updatedCurrentUser));
        window.location.reload(); // Refresh to update balance
      }
    }
  };

  const purchaseTool = (tool: Tool) => {
    if (!currentUser || currentUser.balance < tool.price) {
      alert('Insufficient balance!');
      return;
    }

    // Create investment
    const investment: Investment = {
      id: `inv-${Date.now()}`,
      user_id: currentUser.id,
      tool_id: tool.id,
      amount: tool.price,
      roi_percentage: 30,
      start_date: new Date().toISOString(),
      end_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
      status: 'active',
      final_amount: tool.price * 1.3 // 30% ROI
    };

    // Update user balance
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex((u: any) => u.id === currentUser.id);
    if (userIndex !== -1) {
      users[userIndex].balance -= tool.price;
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('currentUser', JSON.stringify(users[userIndex]));
    }

    // Save investment
    const investments = JSON.parse(localStorage.getItem('investments') || '[]');
    investments.push(investment);
    localStorage.setItem('investments', JSON.stringify(investments));

    alert('Investment successful! You will receive 30% ROI in 7 days.');
    window.location.reload();
  };

  const submitDepositRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const request: DepositRequest = {
      id: `dep-${Date.now()}`,
      user_id: currentUser!.id,
      amount: parseFloat(depositForm.amount),
      phone_number: depositForm.phone_number,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    const requests = JSON.parse(localStorage.getItem('depositRequests') || '[]');
    requests.push(request);
    localStorage.setItem('depositRequests', JSON.stringify(requests));

    setDepositForm({ amount: '', phone_number: '' });
    setShowDepositForm(false);
    alert('Deposit request submitted! Please wait for admin approval.');
  };

  const submitWithdrawRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawForm.amount);
    
    if (amount < 2000) {
      alert('Minimum withdrawal amount is RWF 2,000');
      return;
    }

    if (amount > currentUser!.balance) {
      alert('Insufficient balance!');
      return;
    }

    const request: WithdrawRequest = {
      id: `with-${Date.now()}`,
      user_id: currentUser!.id,
      amount: amount,
      phone_number: withdrawForm.phone_number,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    const requests = JSON.parse(localStorage.getItem('withdrawRequests') || '[]');
    requests.push(request);
    localStorage.setItem('withdrawRequests', JSON.stringify(requests));

    setWithdrawForm({ amount: '', phone_number: '' });
    setShowWithdrawForm(false);
    alert('Withdrawal request submitted! Please wait for admin approval.');
  };

  const getTimeRemaining = (endDate: string) => {
    const now = new Date().getTime();
    const end = new Date(endDate).getTime();
    const diff = end - now;

    if (diff <= 0) return 'Completed';

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    return `${days}d ${hours}h`;
  };

  const getToolName = (toolId: string) => {
    const allTools = JSON.parse(localStorage.getItem('tools') || '[]');
    const tool = allTools.find((t: Tool) => t.id === toolId);
    return tool ? tool.name : 'Unknown Tool';
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Welcome, {currentUser.full_name}</h1>
              <p className="text-gray-600">Icyatsi Investment Platform</p>
            </div>
            <Button onClick={logout} variant="secondary">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Summary & Balance */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="text-center">
            <Wallet className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <h3 className="text-3xl font-bold text-gray-900">RWF {currentUser.balance.toLocaleString()}</h3>
            <p className="text-gray-600">Current Balance</p>
          </Card>
          <Card className="text-center">
            <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <h3 className="text-3xl font-bold text-gray-900">{investments.filter(i => i.status === 'active').length}</h3>
            <p className="text-gray-600">Active Investments</p>
          </Card>
          <Card className="text-center">
            <Calendar className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <h3 className="text-3xl font-bold text-gray-900">{investments.filter(i => i.status === 'completed').length}</h3>
            <p className="text-gray-600">Completed Investments</p>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Deposit Funds</h3>
              <ArrowUpRight className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-gray-600 mb-4">Send money to 0799395017 and submit your deposit details.</p>
            <Button onClick={() => setShowDepositForm(true)} className="w-full">
              <DollarSign className="w-4 h-4 mr-2" />
              Make Deposit
            </Button>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Withdraw Funds</h3>
              <ArrowDownLeft className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-gray-600 mb-4">Minimum withdrawal: RWF 2,000</p>
            <Button 
              onClick={() => setShowWithdrawForm(true)} 
              className="w-full"
              disabled={currentUser.balance < 2000}
            >
              <DollarSign className="w-4 h-4 mr-2" />
              Request Withdrawal
            </Button>
          </Card>
        </div>

        {/* Active Investments */}
        {investments.length > 0 && (
          <Card className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Your Investments</h2>
            <div className="space-y-4">
              {investments.map(investment => (
                <div key={investment.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">{getToolName(investment.tool_id)}</h3>
                    <p className="text-sm text-gray-600">
                      Invested: RWF {investment.amount.toLocaleString()} → Expected: RWF {investment.final_amount.toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`px-3 py-1 rounded-full text-sm ${
                      investment.status === 'active' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {investment.status === 'active' ? (
                        <>
                          <Clock className="w-4 h-4 inline mr-1" />
                          {getTimeRemaining(investment.end_date)}
                        </>
                      ) : (
                        'Completed'
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Tool Store */}
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Investment Tools</h2>
            <Package className="w-6 h-6 text-green-600" />
          </div>
          <p className="text-gray-600 mb-6">Purchase investment tools and earn 30% ROI in 7 days</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tools.map(tool => (
              <div key={tool.id} className="border rounded-xl p-4 hover:shadow-md transition-shadow">
                <img 
                  src={tool.image_url || 'https://images.pexels.com/photos/5483077/pexels-photo-5483077.jpeg'} 
                  alt={tool.name}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="font-semibold text-lg mb-2">{tool.name}</h3>
                <p className="text-gray-600 text-sm mb-4">{tool.description}</p>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold text-green-600">RWF {tool.price.toLocaleString()}</span>
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">+30% ROI</span>
                </div>
                <Button 
                  onClick={() => purchaseTool(tool)}
                  className="w-full"
                  disabled={currentUser.balance < tool.price}
                >
                  {currentUser.balance < tool.price ? 'Insufficient Balance' : 'Invest Now'}
                </Button>
              </div>
            ))}
          </div>
        </Card>
      </main>

      {/* Deposit Form Modal */}
      {showDepositForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-semibold mb-4">Deposit Request</h3>
            <form onSubmit={submitDepositRequest} className="space-y-4">
              <Input
                label="Amount (RWF)"
                type="number"
                value={depositForm.amount}
                onChange={(e) => setDepositForm(prev => ({ ...prev, amount: e.target.value }))}
                required
              />
              <Input
                label="Your Phone Number"
                type="tel"
                value={depositForm.phone_number}
                onChange={(e) => setDepositForm(prev => ({ ...prev, phone_number: e.target.value }))}
                required
              />
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-800">
                  Send your deposit to <strong>0799395017</strong> before submitting this form.
                </p>
              </div>
              <div className="flex space-x-3">
                <Button type="submit" className="flex-1">Submit Request</Button>
                <Button type="button" variant="secondary" onClick={() => setShowDepositForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Withdraw Form Modal */}
      {showWithdrawForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-semibold mb-4">Withdrawal Request</h3>
            <form onSubmit={submitWithdrawRequest} className="space-y-4">
              <Input
                label="Amount (RWF)"
                type="number"
                min="2000"
                max={currentUser.balance}
                value={withdrawForm.amount}
                onChange={(e) => setWithdrawForm(prev => ({ ...prev, amount: e.target.value }))}
                required
              />
              <Input
                label="Your Phone Number"
                type="tel"
                value={withdrawForm.phone_number}
                onChange={(e) => setWithdrawForm(prev => ({ ...prev, phone_number: e.target.value }))}
                required
              />
              <div className="bg-yellow-50 p-3 rounded-lg">
                <p className="text-sm text-yellow-800">
                  Minimum withdrawal: RWF 2,000. Funds will be sent to your phone number after approval.
                </p>
              </div>
              <div className="flex space-x-3">
                <Button type="submit" className="flex-1">Submit Request</Button>
                <Button type="button" variant="secondary" onClick={() => setShowWithdrawForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}