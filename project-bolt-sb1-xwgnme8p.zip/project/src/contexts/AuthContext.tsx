import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  currentUser: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (userData: Omit<User, 'id' | 'created_at' | 'balance' | 'is_admin'>) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initialize admin user if not exists
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const adminExists = users.find((user: User) => user.email === 'enizeyimana36@gmail.com');
    
    if (!adminExists) {
      const adminUser: User = {
        id: 'admin-001',
        full_name: 'System Administrator',
        phone_number: '0799395017',
        email: 'enizeyimana36@gmail.com',
        password: 'Niyigena@2006',
        is_admin: true,
        balance: 0,
        created_at: new Date().toISOString()
      };
      users.push(adminUser);
      localStorage.setItem('users', JSON.stringify(users));
    }

    // Check for logged in user
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      // Step 1: Authenticate user credentials
      const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find(u => u.email === email && u.password === password);
      
      if (!user) {
        return { success: false, error: 'Invalid email or password. Please check your credentials.' };
      }

      // Step 2: Fetch user role and redirect accordingly
      setCurrentUser(user);
      localStorage.setItem('currentUser', JSON.stringify(user));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: 'Login failed. Please try again.' };
    }
  };

  const signup = async (userData: Omit<User, 'id' | 'created_at' | 'balance' | 'is_admin'>): Promise<{ success: boolean; error?: string }> => {
    try {
      // Step 1: Check if email exists in users table
      const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
      const existingUser = users.find(u => u.email === userData.email);
      
      if (existingUser) {
        return { success: false, error: 'Email already registered. Please login or use another email.' };
      }

      // Step 2: Create new user account
      const newUser: User = {
        ...userData,
        id: `user-${Date.now()}`,
        balance: 0,
        is_admin: false, // Set is_admin = false by default
        created_at: new Date().toISOString()
      };

      // Step 3: Insert new record into users table
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      
      // Step 4: Set current user and redirect to /user-dashboard
      setCurrentUser(newUser);
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: 'Failed to create account. Please try again.' };
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const value = {
    currentUser,
    login,
    signup,
    logout,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}