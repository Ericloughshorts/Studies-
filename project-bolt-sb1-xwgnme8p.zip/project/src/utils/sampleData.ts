import { Tool } from '../types';

export const sampleTools: Tool[] = [
  {
    id: 'tool-1',
    name: 'Agricultural Investment Package',
    description: 'Invest in modern farming techniques and equipment. High-yield crops with guaranteed returns.',
    image_url: 'https://images.pexels.com/photos/2406731/pexels-photo-2406731.jpeg',
    price: 50000,
    category: 'Agriculture',
    available: true
  },
  {
    id: 'tool-2',
    name: 'Technology Startup Fund',
    description: 'Fund emerging tech startups in Rwanda. Support innovation while earning returns.',
    image_url: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg',
    price: 100000,
    category: 'Technology',
    available: true
  },
  {
    id: 'tool-3',
    name: 'Real Estate Development',
    description: 'Invest in residential and commercial property development projects.',
    image_url: 'https://images.pexels.com/photos/280229/pexels-photo-280229.jpeg',
    price: 200000,
    category: 'Real Estate',
    available: true
  },
  {
    id: 'tool-4',
    name: 'Small Business Microfinance',
    description: 'Support local entrepreneurs and small businesses with microfinance solutions.',
    image_url: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg',
    price: 25000,
    category: 'Finance',
    available: true
  },
  {
    id: 'tool-5',
    name: 'Renewable Energy Project',
    description: 'Invest in solar and wind energy projects. Clean energy with sustainable returns.',
    image_url: 'https://images.pexels.com/photos/2800832/pexels-photo-2800832.jpeg',
    price: 150000,
    category: 'Energy',
    available: true
  },
  {
    id: 'tool-6',
    name: 'Education Technology Fund',
    description: 'Support educational technology initiatives and digital learning platforms.',
    image_url: 'https://images.pexels.com/photos/4144179/pexels-photo-4144179.jpeg',
    price: 75000,
    category: 'Education',
    available: true
  }
];

// Initialize sample data if not exists
export function initializeSampleData() {
  const existingTools = localStorage.getItem('tools');
  if (!existingTools || JSON.parse(existingTools).length === 0) {
    localStorage.setItem('tools', JSON.stringify(sampleTools));
  }
}